from flask import Flask, render_template, redirect
from data import db_session
from data import job
from data import users
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField, TextAreaField
from wtforms.fields.html5 import EmailField
from wtforms.validators import DataRequired

app = Flask(__name__)
app.config['SECRET_KEY'] = '12345aA'


@app.route('/')
def index():
    db_session.global_init('db/blogs.sqlite')
    session = db_session.create_session()
    jobs = []
    for jb in session.query(job.Jobs).all():
        user = session.query(users.User).filter(users.User.id == jb.team_leader).first()
        finish = 'Is finished'
        if not jb.is_finished:
            finish = 'Is not finished'
        jobs += [(jb.job, user.name, user.surname, jb.work_size, jb.collaborators, finish)]
    return render_template('index.html', list=jobs)


def set_password(self, password):
    self.hashed_password = generate_password_hash(password)


def check_password(self, password):
    return check_password_hash(self.hashed_password, password)


class RegisterForm(FlaskForm):
    email = EmailField('login/email', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    password_again = PasswordField('Repeat password', validators=[DataRequired()])
    surname = StringField('Surname', validators=[DataRequired()])
    name = StringField('Name', validators=[DataRequired()])
    age = StringField('Age', validators=[DataRequired()])
    position = StringField('Position', validators=[DataRequired()])
    speciality = StringField('Speciality', validators=[DataRequired()])
    address = StringField('Address', validators=[DataRequired()])
    submit = SubmitField('Войти')


@app.route('/register', methods=['GET', 'POST'])
def reqister():
    form = RegisterForm()
    if form.validate_on_submit():
        if form.password.data != form.password_again.data:
            return render_template('reg.html', title='Регистрация',
                                   form=form,
                                   message="Пароли не совпадают")
        db_session.global_init('db/blogs.sqlite')
        session = db_session.create_session()
        if session.query(users.User).filter(users.User.email == form.email.data).first():
            return render_template('reg.html', title='Регистрация',
                                   form=form,
                                   message="Такой пользователь уже есть")
        user = users.User(
            name=form.name.data,
            email=form.email.data,
            surname=form.surname.data,
            position=form.position.data,
            age=form.age.data,
            speciality=form.speciality.data,
            address=form.address.data
        )
        user.set_password(form.password.data)
        session.add(user)
        session.commit()
        return redirect('/register')
    return render_template('reg.html', title='Регистрация', form=form)


def main():
    app.run()


if __name__ == '__main__':
    main()
