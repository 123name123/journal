from flask import Flask, render_template
from data import db_session
from data import job
from data import users

app = Flask(__name__)
app.config['SECRET_KEY'] = '12345aA'


@app.route('/')
def index():
    db_session.global_init('db/blogs.sqlite')
    session = db_session.create_session()
    jobs = []
    for jb in session.query(job.Jobs).all():
        user = session.query(users.User).filter(users.User.id == jb.team_leader).first()
        finish = 'Is finished'
        if not jb.is_finished:
            finish = 'Is not finished'
        jobs += [(jb.job, user.name, user.surname, jb.work_size, jb.collaborators, finish)]
    return render_template('index.html', list=jobs)


def main():
    app.run()


if __name__ == '__main__':
    main()
